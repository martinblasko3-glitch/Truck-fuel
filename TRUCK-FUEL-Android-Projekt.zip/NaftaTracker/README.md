# TRUCK FUEL – Android aplikácia

Aplikácia na evidenciu spotreby nafty pre jedno vozidlo (prednastavené IVECO 570 KM), s ručným zapisovaním tankovania a GPS meraním prejdenej vzdialenosti.

## Funkcie
- Ručné tankovanie: stav tachometra, litre, cena za liter, čerpacia stanica a označenie plnej nádrže.
- Priemerná spotreba sa počíta medzi dvoma tankovaniami plnej nádrže. Čiastkové tankovania medzi nimi sa započítajú.
- GPS meranie beží ako služba na pozadí a môže pokračovať aj pri zhasnutom displeji. Vyžaduje povolenie polohy a zapnutú lokalizáciu.
- Uloženie GPS vzdialenosti do histórie jázd.
- Evidencia AdBlue, ručných jázd a histórie tankovania.
- Dáta sa ukladajú lokálne v telefóne.

## Dôležité k presnosti
GPS meria prejdenú vzdialenosť, nie litre spotrebovanej nafty. Na výpočet reálnej spotreby používaj stav tachometra pri tankovaní a tankuj do plna. Počiatočné plné tankovanie nastaví začiatok meracieho intervalu; výsledok spotreby sa zobrazí po ďalšom plnom tankovaní. GPS môže mať odchýlku, najmä v tuneloch, medzi budovami alebo pri slabom signáli.

## Vytvorenie APK bez počítača – cez GitHub v Chrome
1. V telefóne otvor Chrome a prihlás sa na https://github.com.
2. Vytvor nový repozitár cez **New repository**. Názov napríklad `truck-fuel-android`, nastav **Private** alebo **Public** a potvrď **Create repository**.
3. V repozitári zvoľ **Add file → Upload files**.
4. Rozbaľ ZIP projektu v telefóne (aplikácia Súbory → ZIP → Rozbaliť). Otvor priečinok `NaftaTracker` a nahraj jeho OBSAH do koreňa repozitára – priečinky `.github` a `app` a súbory `build.gradle.kts`, `gradle.properties`, `settings.gradle.kts`.
5. Potvrď **Commit changes**.
6. V repozitári otvor kartu **Actions**. Workflow **Build Android APK** sa spustí automaticky. Ak nie, otvor workflow a stlač **Run workflow**.
7. Počkaj, kým bude beh označený zelenou fajkou. Otvor ho, zroluj na **Artifacts** a stiahni `TruckFuel-debug-apk`.
8. V telefóne otvor stiahnutý ZIP artefakt a z neho súbor `app-debug.apk`. Ťukni na APK a povoľ Chrome/Súborom inštaláciu aplikácií z tohto zdroja, ak sa Android opýta.

## Prvé spustenie
- Prednastavené vozidlo je IVECO 570 KM.
- V Tankovaní zadaj aktuálny stav tachometra, litre a cenu. Pri plnej nádrži zaškrtni „Natankoval som plnú nádrž“.
- V karte GPS povoľ polohu a stlač „Spustiť GPS meranie“. Po jazde meranie ukonči a ulož GPS jazdu do histórie.
- V Xiaomi povoľ aplikácii polohu a prípadne nastav batériu na „Bez obmedzení“, aby systém neukončoval GPS meranie na pozadí.

## Technické
- Android min. API 26 (Android 8.0), cieľ API 35.
- APK sa vytvára cez GitHub Actions na JDK 17 a Gradle 8.9.
- Aplikácia zatiaľ nie je podpísaná na publikovanie v Google Play; GitHub vytvorí testovaciu debug APK na inštaláciu do vlastného telefónu.
