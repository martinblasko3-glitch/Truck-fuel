package sk.agrosped.naftatracker

import android.os.Bundle
import android.Manifest
import android.content.Intent
import android.content.pm.PackageManager
import androidx.activity.result.contract.ActivityResultContracts
import androidx.core.content.ContextCompat
import android.content.Context
import androidx.activity.ComponentActivity
import androidx.activity.compose.setContent
import androidx.compose.foundation.layout.*
import androidx.compose.foundation.lazy.LazyColumn
import androidx.compose.foundation.lazy.items
import androidx.compose.foundation.rememberScrollState
import androidx.compose.foundation.verticalScroll
import androidx.compose.material.icons.Icons
import androidx.compose.material.icons.filled.Add
import androidx.compose.material.icons.filled.LocalGasStation
import androidx.compose.material.icons.filled.DirectionsCar
import androidx.compose.material.icons.filled.Route
import androidx.compose.material3.*
import androidx.compose.runtime.*
import androidx.compose.ui.Modifier
import androidx.compose.ui.unit.dp
import androidx.room.*
import androidx.room.Room
import androidx.room.migration.Migration
import androidx.sqlite.db.SupportSQLiteDatabase
import kotlinx.coroutines.launch
import java.text.SimpleDateFormat
import java.util.Date
import java.util.Locale

@Entity(tableName = "vehicles")
data class Vehicle(@PrimaryKey(autoGenerate = true) val id: Long = 0, val name: String, val registration: String = "")

@Entity(
    tableName = "refuels",
    indices = [Index("vehicleId")]
)
data class Refuel(
    @PrimaryKey(autoGenerate = true) val id: Long = 0,
    val vehicleId: Long,
    val date: Long,
    val odometer: Double,
    val liters: Double,
    val pricePerLiter: Double,
    val fullTank: Boolean,
    val station: String
)

@Entity(tableName = "adblue_refuels", indices = [Index("vehicleId")])
data class AdBlueRefuel(
    @PrimaryKey(autoGenerate = true) val id: Long = 0,
    val vehicleId: Long,
    val date: Long,
    val odometer: Double,
    val liters: Double,
    val pricePerLiter: Double,
    val station: String
)

@Entity(tableName = "trips", indices = [Index("vehicleId")])
data class Trip(
    @PrimaryKey(autoGenerate = true) val id: Long = 0,
    val vehicleId: Long,
    val date: Long,
    val startKm: Double,
    val endKm: Double,
    val note: String
)

@Dao
interface TrackerDao {
    @Query("SELECT * FROM vehicles ORDER BY id")
    fun vehicles(): kotlinx.coroutines.flow.Flow<List<Vehicle>>
    @Insert suspend fun addVehicle(v: Vehicle): Long
    @Delete suspend fun deleteVehicle(v: Vehicle)
    @Query("SELECT * FROM refuels WHERE vehicleId=:vehicleId ORDER BY date, id")
    fun refuels(vehicleId: Long): kotlinx.coroutines.flow.Flow<List<Refuel>>
    @Insert suspend fun addRefuel(r: Refuel)
    @Query("SELECT * FROM adblue_refuels WHERE vehicleId=:vehicleId ORDER BY date, id")
    fun adBlueRefuels(vehicleId: Long): kotlinx.coroutines.flow.Flow<List<AdBlueRefuel>>
    @Insert suspend fun addAdBlueRefuel(r: AdBlueRefuel)
    @Query("SELECT * FROM trips WHERE vehicleId=:vehicleId ORDER BY date DESC")
    fun trips(vehicleId: Long): kotlinx.coroutines.flow.Flow<List<Trip>>
    @Insert suspend fun addTrip(t: Trip)
}

@Database(entities = [Vehicle::class, Refuel::class, AdBlueRefuel::class, Trip::class], version = 2, exportSchema = false)
abstract class TrackerDb : RoomDatabase() {
    abstract fun dao(): TrackerDao
    companion object {
        @Volatile private var INSTANCE: TrackerDb? = null
        fun get(context: android.content.Context): TrackerDb =
            INSTANCE ?: synchronized(this) {
                INSTANCE ?: Room.databaseBuilder(context.applicationContext, TrackerDb::class.java, "nafta_tracker.db")
                    .addMigrations(object : Migration(1, 2) {
                        override fun migrate(database: SupportSQLiteDatabase) {
                            database.execSQL("CREATE TABLE IF NOT EXISTS adblue_refuels (id INTEGER PRIMARY KEY AUTOINCREMENT NOT NULL, vehicleId INTEGER NOT NULL, date INTEGER NOT NULL, odometer REAL NOT NULL, liters REAL NOT NULL, pricePerLiter REAL NOT NULL, station TEXT NOT NULL)")
                            database.execSQL("CREATE INDEX IF NOT EXISTS index_adblue_refuels_vehicleId ON adblue_refuels(vehicleId)")
                        }
                    })
                    .build().also { INSTANCE = it }
            }
    }
}

class MainActivity : ComponentActivity() {
    private val locationPermission = registerForActivityResult(ActivityResultContracts.RequestMultiplePermissions()) { grants ->
        if (grants[Manifest.permission.ACCESS_FINE_LOCATION] == true || grants[Manifest.permission.ACCESS_COARSE_LOCATION] == true) {
            startGpsTracking()
        }
    }
    private fun startGpsTracking() {
        ContextCompat.startForegroundService(this, Intent(this, GpsTrackingService::class.java).setAction(GpsTrackingService.ACTION_START))
    }
    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        val dao = TrackerDb.get(this).dao()
        setContent { MaterialTheme { TrackerApp(dao, onStartGps = {
            val fine = ContextCompat.checkSelfPermission(this, Manifest.permission.ACCESS_FINE_LOCATION) == PackageManager.PERMISSION_GRANTED
            val coarse = ContextCompat.checkSelfPermission(this, Manifest.permission.ACCESS_COARSE_LOCATION) == PackageManager.PERMISSION_GRANTED
            if (fine || coarse) startGpsTracking() else locationPermission.launch(arrayOf(Manifest.permission.ACCESS_FINE_LOCATION, Manifest.permission.ACCESS_COARSE_LOCATION))
        }, onStopGps = { startService(Intent(this, GpsTrackingService::class.java).setAction(GpsTrackingService.ACTION_STOP)) }, context = this) } }
    }
}

@OptIn(ExperimentalMaterial3Api::class)
@Composable
fun TrackerApp(dao: TrackerDao, onStartGps: () -> Unit, onStopGps: () -> Unit, context: Context) {
    val scope = rememberCoroutineScope()
    val vehicles by dao.vehicles().collectAsState(initial = emptyList())
    var selectedId by remember { mutableLongStateOf(0L) }
    var seededVehicle by remember { mutableStateOf(false) }
    LaunchedEffect(vehicles) {
        if (!seededVehicle) {
            seededVehicle = true
            if (vehicles.isEmpty()) dao.addVehicle(Vehicle(name = "IVECO 570 KM"))
        }
        if (selectedId == 0L && vehicles.isNotEmpty()) selectedId = vehicles.first().id
    }
    val selected = vehicles.firstOrNull { it.id == selectedId }
    val refuels by if (selectedId != 0L) dao.refuels(selectedId).collectAsState(initial = emptyList())
        else remember { mutableStateOf(emptyList()) }
    val trips by if (selectedId != 0L) dao.trips(selectedId).collectAsState(initial = emptyList())
        else remember { mutableStateOf(emptyList()) }
    val adBlueRecords by if (selectedId != 0L) dao.adBlueRefuels(selectedId).collectAsState(initial = emptyList())
        else remember { mutableStateOf(emptyList()) }

    var tab by remember { mutableIntStateOf(0) }
    var showVehicle by remember { mutableStateOf(false) }
    var showRefuel by remember { mutableStateOf(false) }
    var showTrip by remember { mutableStateOf(false) }
    var showAdBlue by remember { mutableStateOf(false) }
    var gpsDistance by remember { mutableDoubleStateOf(0.0) }
    var gpsActive by remember { mutableStateOf(false) }
    var gpsStarted by remember { mutableLongStateOf(0L) }
    LaunchedEffect(Unit) {
        while (true) {
            val prefs = context.getSharedPreferences(GpsTrackingService.PREFS, Context.MODE_PRIVATE)
            gpsDistance = prefs.getFloat("distance_km", 0f).toDouble()
            gpsActive = prefs.getBoolean("active", false)
            gpsStarted = prefs.getLong("started_at", 0L)
            kotlinx.coroutines.delay(1000)
        }
    }

    Scaffold(
        topBar = {
            TopAppBar(title = { Column { Text("TRUCK FUEL"); Text("Evidencia spotreby a jázd", style = MaterialTheme.typography.labelSmall) } })
        },
        floatingActionButton = {
            if (tab != 0 && tab != 4) FloatingActionButton(onClick = {
                when (tab) {
                    1 -> showRefuel = selected != null
                    2 -> showAdBlue = selected != null
                    3 -> showTrip = selected != null
                }
            }) { Icon(Icons.Default.Add, contentDescription = "Pridať") }
        },
        bottomBar = {
            NavigationBar {
                NavigationBarItem(selected = tab == 0, onClick = { tab = 0 }, icon = { Icon(Icons.Default.DirectionsCar, null) }, label = { Text("Vozidlá") })
                NavigationBarItem(selected = tab == 1, onClick = { tab = 1 }, icon = { Icon(Icons.Default.LocalGasStation, null) }, label = { Text("Tankovanie") })
                NavigationBarItem(selected = tab == 2, onClick = { tab = 2 }, icon = { Icon(Icons.Default.LocalGasStation, null) }, label = { Text("AdBlue") })
                NavigationBarItem(selected = tab == 3, onClick = { tab = 3 }, icon = { Icon(Icons.Default.Route, null) }, label = { Text("Jazdy") })
                NavigationBarItem(selected = tab == 4, onClick = { tab = 4 }, icon = { Icon(Icons.Default.Route, null) }, label = { Text("GPS") })
            }
        }
    ) { padding ->
        Column(Modifier.padding(padding).fillMaxSize().padding(16.dp)) {
            if (vehicles.isNotEmpty()) {
                var expanded by remember { mutableStateOf(false) }
                ExposedDropdownMenuBox(expanded = expanded, onExpandedChange = { expanded = !expanded }) {
                    OutlinedTextField(
                        value = selected?.let { "${it.name} ${it.registration}".trim() } ?: "Vyber vozidlo",
                        onValueChange = {}, readOnly = true, label = { Text("Aktívne vozidlo") },
                        trailingIcon = { ExposedDropdownMenuDefaults.TrailingIcon(expanded) },
                        modifier = Modifier.menuAnchor().fillMaxWidth()
                    )
                    ExposedDropdownMenu(expanded = expanded, onDismissRequest = { expanded = false }) {
                        vehicles.forEach { v -> DropdownMenuItem(text = { Text("${v.name} ${v.registration}".trim()) }, onClick = { selectedId = v.id; expanded = false }) }
                    }
                }
                Spacer(Modifier.height(12.dp))
            }
            when (tab) {
                0 -> VehicleScreen(vehicles, selectedId, { selectedId = it })
                1 -> if (selected == null) EmptyHint("Najprv pridaj vozidlo.") else RefuelScreen(refuels, selected.name)
                2 -> if (selected == null) EmptyHint("Najprv pridaj vozidlo.") else AdBlueScreen(adBlueRecords)
                3 -> if (selected == null) EmptyHint("Najprv pridaj vozidlo.") else TripScreen(trips)
                else -> GpsScreen(gpsDistance, gpsActive, gpsStarted, onStartGps, onStopGps, onSave = {
                    if (selected != null && gpsDistance > 0.01) {
                        scope.launch { dao.addTrip(Trip(vehicleId = selected.id, date = System.currentTimeMillis(), startKm = 0.0, endKm = gpsDistance, note = "GPS jazda – vzdialenosť")) }
                        context.getSharedPreferences(GpsTrackingService.PREFS, Context.MODE_PRIVATE).edit().putFloat("distance_km", 0f).putLong("started_at", 0L).apply()
                    }
                })
            }
        }
    }

    if (showVehicle) VehicleDialog(
        onDismiss = { showVehicle = false },
        onSave = { name, reg -> scope.launch { val id = dao.addVehicle(Vehicle(name = name, registration = reg)); selectedId = id }; showVehicle = false }
    )
    if (showRefuel && selected != null) RefuelDialog(
        onDismiss = { showRefuel = false },
        onSave = { km, liters, price, full, station ->
            scope.launch { dao.addRefuel(Refuel(vehicleId = selected.id, date = System.currentTimeMillis(), odometer = km, liters = liters, pricePerLiter = price, fullTank = full, station = station)) }
            showRefuel = false
        }
    )
    if (showAdBlue && selected != null) AdBlueDialog(
        onDismiss = { showAdBlue = false },
        onSave = { km, liters, price, station ->
            scope.launch { dao.addAdBlueRefuel(AdBlueRefuel(vehicleId = selected.id, date = System.currentTimeMillis(), odometer = km, liters = liters, pricePerLiter = price, station = station)) }
            showAdBlue = false
        }
    )
    if (showTrip && selected != null) TripDialog(
        onDismiss = { showTrip = false },
        onSave = { start, end, note ->
            scope.launch { dao.addTrip(Trip(vehicleId = selected.id, date = System.currentTimeMillis(), startKm = start, endKm = end, note = note)) }
            showTrip = false
        }
    )
}


@Composable
fun GpsScreen(distance: Double, active: Boolean, started: Long, onStart: () -> Unit, onStop: () -> Unit, onSave: () -> Unit) {
    Column(Modifier.fillMaxSize().verticalScroll(rememberScrollState()), verticalArrangement = Arrangement.spacedBy(14.dp)) {
        Text("GPS meranie jazdy", style = MaterialTheme.typography.titleLarge)
        Card(Modifier.fillMaxWidth()) {
            Column(Modifier.padding(20.dp), verticalArrangement = Arrangement.spacedBy(8.dp)) {
                Text(if (active) "MERANIE JE AKTÍVNE" else "GPS MERANIE JE ZASTAVENÉ", color = if (active) MaterialTheme.colorScheme.primary else MaterialTheme.colorScheme.onSurfaceVariant)
                Text("%.2f km".format(distance), style = MaterialTheme.typography.headlineLarge)
                Text("Prejdená vzdialenosť GPS")
                if (started > 0) Text("Začiatok: ${dateText(started)}")
            }
        }
        if (active) Button(onClick = onStop, modifier = Modifier.fillMaxWidth()) { Text("Ukončiť meranie") }
        else Button(onClick = onStart, modifier = Modifier.fillMaxWidth()) { Text("Spustiť GPS meranie") }
        OutlinedButton(onClick = onSave, enabled = !active && distance > 0.01, modifier = Modifier.fillMaxWidth()) { Text("Uložiť GPS jazdu do histórie") }
        Text("GPS meria vzdialenosť aj pri zhasnutom displeji. Pri prvom spustení povoľ prístup k polohe. Pre presnejší výsledok maj zapnutú polohu a telefón na mieste s dobrým výhľadom na oblohu.")
        Text("Poznámka: GPS meria kilometre. Spotreba nafty sa vypočíta z tankovania a stavov tachometra.", style = MaterialTheme.typography.bodySmall, color = MaterialTheme.colorScheme.onSurfaceVariant)
    }
}

@Composable
fun VehicleScreen(vehicles: List<Vehicle>, selected: Long, onSelect: (Long) -> Unit) {
    Text("Moje vozidlo", style = MaterialTheme.typography.titleLarge)
    Spacer(Modifier.height(8.dp))
    if (vehicles.isEmpty()) EmptyHint("Pripravujem vozidlo IVECO 570 KM…")
    LazyColumn(verticalArrangement = Arrangement.spacedBy(8.dp)) {
        items(vehicles) { v ->
            Card {
                Column(Modifier.fillMaxWidth().padding(16.dp)) {
                    Text(v.name, style = MaterialTheme.typography.titleMedium)
                    if (v.registration.isNotBlank()) Text("EČV: ${v.registration}")
                    Text("Aktívne vozidlo", color = MaterialTheme.colorScheme.primary)
                }
            }
        }
    }
}

@Composable
fun RefuelScreen(records: List<Refuel>, vehicleName: String) {
    val stats = remember(records) { calculate(records) }
    Text("Tankovanie – $vehicleName", style = MaterialTheme.typography.titleLarge)
    Spacer(Modifier.height(8.dp))
    Card(Modifier.fillMaxWidth()) {
        Column(Modifier.padding(16.dp)) {
            Text("Priemerná spotreba", style = MaterialTheme.typography.labelLarge)
            Text(if (stats.first > 0) "%.2f l/100 km".format(stats.first) else "Zatiaľ nie je dosť údajov", style = MaterialTheme.typography.headlineSmall)
            Text("${"%.1f".format(stats.second)} km v uzavretých intervaloch • ${"%.1f".format(stats.third)} l")
        }
    }
    Spacer(Modifier.height(12.dp))
    Text("Záznamy tankovania", style = MaterialTheme.typography.titleMedium)
    if (records.isEmpty()) EmptyHint("Pridaj prvé tankovanie cez tlačidlo +.")
    LazyColumn(verticalArrangement = Arrangement.spacedBy(8.dp)) {
        items(records.sortedByDescending { it.date }) { r ->
            Card {
                Column(Modifier.padding(12.dp)) {
                    Text("${dateText(r.date)} • ${"%.1f".format(r.liters)} l", style = MaterialTheme.typography.titleMedium)
                    Text("Stav km: ${"%.0f".format(r.odometer)} • ${"%.2f".format(r.pricePerLiter)} €/l")
                    if (r.station.isNotBlank()) Text(r.station)
                    Text(if (r.fullTank) "Plná nádrž" else "Čiastočné tankovanie", color = MaterialTheme.colorScheme.primary)
                    Text("Spolu: ${"%.2f".format(r.liters * r.pricePerLiter)} €")
                }
            }
        }
    }
}

@Composable
fun TripScreen(trips: List<Trip>) {
    Text("Evidencia jázd", style = MaterialTheme.typography.titleLarge)
    Spacer(Modifier.height(8.dp))
    if (trips.isEmpty()) EmptyHint("Pridaj jazdu cez + a zaznamenaj počiatočný a konečný stav kilometrov.")
    LazyColumn(verticalArrangement = Arrangement.spacedBy(8.dp)) {
        items(trips) { t ->
            Card {
                Column(Modifier.padding(12.dp)) {
                    Text(dateText(t.date), style = MaterialTheme.typography.titleMedium)
                    if (t.note.startsWith("GPS")) Text("GPS vzdialenosť: ${"%.2f".format(t.endKm)} km")
                    else Text("${"%.0f".format(t.startKm)} → ${"%.0f".format(t.endKm)} km  •  ${"%.1f".format(t.endKm - t.startKm)} km")
                    if (t.note.isNotBlank()) Text(t.note)
                }
            }
        }
    }
}

fun calculate(records: List<Refuel>): Triple<Double, Double, Double> {
    val sorted = records.sortedWith(compareBy<Refuel> { it.date }.thenBy { it.id })
    val fulls = sorted.indices.filter { sorted[it].fullTank }
    var kmTotal = 0.0
    var litersTotal = 0.0
    for (i in 1 until fulls.size) {
        val prev = fulls[i - 1]
        val curr = fulls[i]
        val distance = sorted[curr].odometer - sorted[prev].odometer
        if (distance > 0) {
            val liters = sorted.subList(prev + 1, curr + 1).sumOf { it.liters }
            kmTotal += distance
            litersTotal += liters
        }
    }
    return Triple(if (kmTotal > 0) litersTotal / kmTotal * 100 else 0.0, kmTotal, litersTotal)
}

fun dateText(ms: Long) = SimpleDateFormat("dd.MM.yyyy HH:mm", Locale("sk", "SK")).format(Date(ms))

@Composable
fun EmptyHint(text: String) { Text(text, color = MaterialTheme.colorScheme.onSurfaceVariant, modifier = Modifier.padding(vertical = 16.dp)) }

@Composable
fun VehicleDialog(onDismiss: () -> Unit, onSave: (String, String) -> Unit) {
    var name by remember { mutableStateOf("IVECO 570 KM") }
    var reg by remember { mutableStateOf("") }
    AlertDialog(onDismissRequest = onDismiss, title = { Text("Nové vozidlo") },
        text = { Column { OutlinedTextField(name, { name = it }, label = { Text("Názov vozidla") }); OutlinedTextField(reg, { reg = it }, label = { Text("EČV (nepovinné)") }) } },
        confirmButton = { TextButton(onClick = { if (name.isNotBlank()) onSave(name.trim(), reg.trim()) }) { Text("Uložiť") } },
        dismissButton = { TextButton(onClick = onDismiss) { Text("Zrušiť") } })
}

@Composable
fun RefuelDialog(onDismiss: () -> Unit, onSave: (Double, Double, Double, Boolean, String) -> Unit) {
    var km by remember { mutableStateOf("") }
    var liters by remember { mutableStateOf("") }
    var price by remember { mutableStateOf("") }
    var station by remember { mutableStateOf("") }
    var full by remember { mutableStateOf(true) }
    val valid = (km.toDoubleOrNull() ?: 0.0) > 0 && (liters.toDoubleOrNull() ?: 0.0) > 0 && (price.toDoubleOrNull() ?: -1.0) >= 0
    AlertDialog(onDismissRequest = onDismiss, title = { Text("Pridať tankovanie") },
        text = { Column(Modifier.heightIn(max = 440.dp).verticalScroll(rememberScrollState())) {
            OutlinedTextField(km, { km = it }, label = { Text("Stav kilometrov") })
            OutlinedTextField(liters, { liters = it }, label = { Text("Natankované litre") })
            OutlinedTextField(price, { price = it }, label = { Text("Cena za liter (€)") })
            OutlinedTextField(station, { station = it }, label = { Text("Čerpacia stanica / miesto") })
            Row { Checkbox(full, { full = it }); Text("Natankoval som plnú nádrž", modifier = Modifier.padding(top = 12.dp)) }
            Text("Spotreba sa počíta medzi dvoma tankovaniami plnej nádrže. Medzitým môžeš pridať aj čiastočné tankovania.")
        } },
        confirmButton = { TextButton(enabled = valid, onClick = { onSave(km.toDouble(), liters.toDouble(), price.toDouble(), full, station.trim()) }) { Text("Uložiť") } },
        dismissButton = { TextButton(onClick = onDismiss) { Text("Zrušiť") } })
}

@Composable
fun TripDialog(onDismiss: () -> Unit, onSave: (Double, Double, String) -> Unit) {
    var start by remember { mutableStateOf("") }
    var end by remember { mutableStateOf("") }
    var note by remember { mutableStateOf("") }
    val valid = (start.toDoubleOrNull() ?: -1.0) >= 0 && (end.toDoubleOrNull() ?: 0.0) > (start.toDoubleOrNull() ?: 0.0)
    AlertDialog(onDismissRequest = onDismiss, title = { Text("Pridať jazdu") },
        text = { Column(Modifier.verticalScroll(rememberScrollState())) {
            OutlinedTextField(start, { start = it }, label = { Text("Počiatočný stav km") })
            OutlinedTextField(end, { end = it }, label = { Text("Konečný stav km") })
            OutlinedTextField(note, { note = it }, label = { Text("Poznámka / trasa") })
        } },
        confirmButton = { TextButton(enabled = valid, onClick = { onSave(start.toDouble(), end.toDouble(), note.trim()) }) { Text("Uložiť") } },
        dismissButton = { TextButton(onClick = onDismiss) { Text("Zrušiť") } })
}
