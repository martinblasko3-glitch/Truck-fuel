package sk.agrosped.naftatracker

import android.app.Notification
import android.app.NotificationChannel
import android.app.NotificationManager
import android.app.Service
import android.content.Context
import android.content.Intent
import android.location.Location
import android.location.LocationListener
import android.location.LocationManager
import android.os.Build
import android.os.IBinder
import android.os.Looper
import androidx.core.app.NotificationCompat

class GpsTrackingService : Service(), LocationListener {
    private lateinit var locationManager: LocationManager
    private var previous: Location? = null
    private var distanceKm = 0.0
    private var startedAt = 0L
    private val prefs by lazy { getSharedPreferences(PREFS, Context.MODE_PRIVATE) }

    override fun onCreate() {
        super.onCreate()
        locationManager = getSystemService(Context.LOCATION_SERVICE) as LocationManager
        createChannel()
    }

    override fun onStartCommand(intent: Intent?, flags: Int, startId: Int): Int {
        when (intent?.action) {
            ACTION_STOP -> stopTracking()
            ACTION_START -> startTracking(false)
            null -> if (prefs.getBoolean("active", false)) startTracking(true) else stopSelf()
        }
        return START_STICKY
    }

    private fun startTracking(resume: Boolean) {
        if (!resume) {
            distanceKm = 0.0
            startedAt = System.currentTimeMillis()
            prefs.edit().putFloat("distance_km", 0f).putLong("started_at", startedAt).putBoolean("active", true).apply()
        } else {
            distanceKm = prefs.getFloat("distance_km", 0f).toDouble()
            startedAt = prefs.getLong("started_at", System.currentTimeMillis())
        }
        previous = null
        startForeground(NOTIFICATION_ID, notification("GPS meria prejdenú vzdialenosť"))
        try {
            val fine = checkSelfPermission(android.Manifest.permission.ACCESS_FINE_LOCATION) == android.content.pm.PackageManager.PERMISSION_GRANTED
            val coarse = checkSelfPermission(android.Manifest.permission.ACCESS_COARSE_LOCATION) == android.content.pm.PackageManager.PERMISSION_GRANTED
            if (fine) locationManager.requestLocationUpdates(LocationManager.GPS_PROVIDER, 3000L, 5f, this, Looper.getMainLooper())
            if (coarse) locationManager.requestLocationUpdates(LocationManager.NETWORK_PROVIDER, 5000L, 10f, this, Looper.getMainLooper())
            if (!fine && !coarse) throw SecurityException("Location permission missing")
        } catch (_: Exception) {
            prefs.edit().putBoolean("active", false).apply()
            stopForeground(STOP_FOREGROUND_REMOVE)
            stopSelf()
        }
    }

    override fun onLocationChanged(location: Location) {
        val last = previous
        if (last != null && location.accuracy <= 50f) {
            val delta = last.distanceTo(location)
            // Reject implausible GPS jumps while the truck is moving.
            if (delta in 3f..1500f) distanceKm += delta / 1000.0
        }
        previous = location
        prefs.edit().putFloat("distance_km", distanceKm.toFloat()).apply()
        val manager = getSystemService(Context.NOTIFICATION_SERVICE) as NotificationManager
        manager.notify(NOTIFICATION_ID, notification("Prejdené: %.2f km".format(distanceKm)))
    }

    private fun stopTracking() {
        distanceKm = prefs.getFloat("distance_km", 0f).toDouble()
        try { locationManager.removeUpdates(this) } catch (_: Exception) { }
        prefs.edit().putBoolean("active", false).putFloat("distance_km", distanceKm.toFloat()).apply()
        stopForeground(STOP_FOREGROUND_REMOVE)
        stopSelf()
    }

    private fun notification(text: String): Notification = NotificationCompat.Builder(this, CHANNEL_ID)
        .setContentTitle("TRUCK FUEL – GPS")
        .setContentText(text)
        .setSmallIcon(android.R.drawable.ic_menu_mylocation)
        .setOngoing(true)
        .build()

    private fun createChannel() {
        if (Build.VERSION.SDK_INT >= Build.VERSION_CODES.O) {
            val channel = NotificationChannel(CHANNEL_ID, "GPS meranie", NotificationManager.IMPORTANCE_LOW)
            (getSystemService(Context.NOTIFICATION_SERVICE) as NotificationManager).createNotificationChannel(channel)
        }
    }

    override fun onProviderEnabled(provider: String) {}
    override fun onProviderDisabled(provider: String) {}
    @Deprecated("Deprecated in Android API") override fun onStatusChanged(provider: String?, status: Int, extras: android.os.Bundle?) {}
    override fun onBind(intent: Intent?): IBinder? = null

    companion object {
        const val ACTION_START = "sk.agrosped.truckfuel.START_GPS"
        const val ACTION_STOP = "sk.agrosped.truckfuel.STOP_GPS"
        const val PREFS = "truck_fuel_gps"
        private const val CHANNEL_ID = "truck_fuel_gps_channel"
        private const val NOTIFICATION_ID = 570
    }
}
